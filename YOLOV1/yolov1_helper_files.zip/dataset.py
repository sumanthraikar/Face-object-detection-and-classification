import torch 
import os
import numpy as np
from PIL import Image
from torch.utils.data import Dataset


class Facedataset(Dataset):

    def __init__(self, image_dir, label_dir, S=7, B=2, C=4, transforms=None):

        self.image_dir = image_dir
        self.label_dir = label_dir
        self.S=S
        self.B=B
        self.C=C
        self.images = os.listdir(image_dir)
        self.transforms = transforms

    def __len__(self):
        return len(self.images)
    
    def __getitem__(self, index):
        image_path = os.path.join(self.image_dir, self.images[index])
        label_path = os.path.join(self.label_dir, self.images[index].replace(".jpg", ".txt"))

        image = np.array(Image.open(image_path).convert("RGB"))

        boxes = []
        with open(label_path) as file:
            for label in file.readlines():
                class_label,x,y,w,h = [float(i) if float(i) != int(float(i)) else int(float(i)) for i in label.replace("\n", "").split()]
                boxes.append([class_label,x,y,w,h])


        label_matrix = torch.zeros((self.S, self.S, self.C+5*self.B))
        for box in boxes:
            class_label, x,y, w, h = box
            class_label = int(class_label)
            i,j = int(self.S*y), int(self.S*x)
            x_cell, y_cell = self.S*x-j, self.S*y-i
            w_cell, h_cell = (w*self.S, h*self.S)
            
            if label_matrix[i,j,4]==0:
                label_matrix[i,j,4]=1
                box_coordinates = torch.tensor([x_cell, y_cell, w_cell, h_cell])
                label_matrix[i,j,5:9] = box_coordinates
                label_matrix[i,j,class_label] = 1

        return image, label_matrix
    

